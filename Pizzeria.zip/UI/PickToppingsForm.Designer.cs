﻿namespace Pizzeria
{
    partial class PickToppings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.okButton = new System.Windows.Forms.Button();
            this.lactoseFreeCheeseCheckBox = new System.Windows.Forms.CheckBox();
            this.addTopingsLbl = new System.Windows.Forms.Label();
            this.regularCheeseNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.mozzarellaNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.fetaNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.cheddarNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.parmesanNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.baconNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.mushroomsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.sausageNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.salamiNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.hamNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.anchoviesNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.onionsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.bellPepperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.jalapenoNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.olivesNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.blackOlivesNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.spinachNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.oreganoNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.basilNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.garlicNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.chiliPepperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.tomatoNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.mozzarellaLbl = new System.Windows.Forms.Label();
            this.regularCheeseLbl = new System.Windows.Forms.Label();
            this.parmesanLbl = new System.Windows.Forms.Label();
            this.cheddarLbl = new System.Windows.Forms.Label();
            this.fetaLbl = new System.Windows.Forms.Label();
            this.hamLbl = new System.Windows.Forms.Label();
            this.sausageLbl = new System.Windows.Forms.Label();
            this.baconLbl = new System.Windows.Forms.Label();
            this.anchoviesLbl = new System.Windows.Forms.Label();
            this.salamiLbl = new System.Windows.Forms.Label();
            this.mushroomsLbl = new System.Windows.Forms.Label();
            this.olivesLbl = new System.Windows.Forms.Label();
            this.bellPepperLbl = new System.Windows.Forms.Label();
            this.onionsLbl = new System.Windows.Forms.Label();
            this.blackOlivesLbl = new System.Windows.Forms.Label();
            this.jalapenoLbl = new System.Windows.Forms.Label();
            this.chiliPepperLbl = new System.Windows.Forms.Label();
            this.basilLbl = new System.Windows.Forms.Label();
            this.spinachLbl = new System.Windows.Forms.Label();
            this.tomatoLbl = new System.Windows.Forms.Label();
            this.garlicLbl = new System.Windows.Forms.Label();
            this.oreganoLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.regularCheeseNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mozzarellaNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fetaNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cheddarNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.parmesanNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baconNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mushroomsNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sausageNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salamiNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hamNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.anchoviesNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onionsNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bellPepperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jalapenoNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.olivesNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackOlivesNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinachNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oreganoNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basilNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.garlicNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiliPepperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tomatoNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // okButton
            // 
            this.okButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.okButton.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.okButton.Location = new System.Drawing.Point(222, 1146);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(145, 44);
            this.okButton.TabIndex = 31;
            this.okButton.Text = "Ok";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // lactoseFreeCheeseCheckBox
            // 
            this.lactoseFreeCheeseCheckBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lactoseFreeCheeseCheckBox.AutoSize = true;
            this.lactoseFreeCheeseCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lactoseFreeCheeseCheckBox.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lactoseFreeCheeseCheckBox.Location = new System.Drawing.Point(150, 171);
            this.lactoseFreeCheeseCheckBox.Name = "lactoseFreeCheeseCheckBox";
            this.lactoseFreeCheeseCheckBox.Size = new System.Drawing.Size(227, 36);
            this.lactoseFreeCheeseCheckBox.TabIndex = 29;
            this.lactoseFreeCheeseCheckBox.Text = "Lactose-free pizza";
            this.lactoseFreeCheeseCheckBox.UseVisualStyleBackColor = true;
            this.lactoseFreeCheeseCheckBox.CheckedChanged += new System.EventHandler(this.lactoseFreeCheeseCheckBox_CheckedChanged);
            // 
            // addTopingsLbl
            // 
            this.addTopingsLbl.AutoSize = true;
            this.addTopingsLbl.Font = new System.Drawing.Font("Palatino Linotype", 14F);
            this.addTopingsLbl.Location = new System.Drawing.Point(234, 19);
            this.addTopingsLbl.Name = "addTopingsLbl";
            this.addTopingsLbl.Size = new System.Drawing.Size(187, 37);
            this.addTopingsLbl.TabIndex = 57;
            this.addTopingsLbl.Text = "Add toppings";
            // 
            // regularCheeseNumericUpDown
            // 
            this.regularCheeseNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.regularCheeseNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.regularCheeseNumericUpDown.Location = new System.Drawing.Point(475, 125);
            this.regularCheeseNumericUpDown.Name = "regularCheeseNumericUpDown";
            this.regularCheeseNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.regularCheeseNumericUpDown.TabIndex = 55;
            this.regularCheeseNumericUpDown.ValueChanged += new System.EventHandler(this.regularCheeseNumericUpDown_ValueChanged);
            // 
            // mozzarellaNumericUpDown
            // 
            this.mozzarellaNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.mozzarellaNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mozzarellaNumericUpDown.Location = new System.Drawing.Point(475, 79);
            this.mozzarellaNumericUpDown.Name = "mozzarellaNumericUpDown";
            this.mozzarellaNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.mozzarellaNumericUpDown.TabIndex = 55;
            this.mozzarellaNumericUpDown.ValueChanged += new System.EventHandler(this.mozzarellaNumericUpDown_ValueChanged);
            // 
            // fetaNumericUpDown
            // 
            this.fetaNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.fetaNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fetaNumericUpDown.Location = new System.Drawing.Point(475, 309);
            this.fetaNumericUpDown.Name = "fetaNumericUpDown";
            this.fetaNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.fetaNumericUpDown.TabIndex = 55;
            this.fetaNumericUpDown.ValueChanged += new System.EventHandler(this.fetaNumericUpDown_ValueChanged);
            // 
            // cheddarNumericUpDown
            // 
            this.cheddarNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.cheddarNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cheddarNumericUpDown.Location = new System.Drawing.Point(475, 263);
            this.cheddarNumericUpDown.Name = "cheddarNumericUpDown";
            this.cheddarNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.cheddarNumericUpDown.TabIndex = 55;
            this.cheddarNumericUpDown.ValueChanged += new System.EventHandler(this.cheddarNumericUpDown_ValueChanged);
            // 
            // parmesanNumericUpDown
            // 
            this.parmesanNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.parmesanNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.parmesanNumericUpDown.Location = new System.Drawing.Point(475, 219);
            this.parmesanNumericUpDown.Name = "parmesanNumericUpDown";
            this.parmesanNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.parmesanNumericUpDown.TabIndex = 55;
            this.parmesanNumericUpDown.ValueChanged += new System.EventHandler(this.parmesanNumericUpDown_ValueChanged);
            // 
            // baconNumericUpDown
            // 
            this.baconNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.baconNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.baconNumericUpDown.Location = new System.Drawing.Point(475, 447);
            this.baconNumericUpDown.Name = "baconNumericUpDown";
            this.baconNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.baconNumericUpDown.TabIndex = 55;
            this.baconNumericUpDown.ValueChanged += new System.EventHandler(this.baconNumericUpDown_ValueChanged);
            // 
            // mushroomsNumericUpDown
            // 
            this.mushroomsNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.mushroomsNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.mushroomsNumericUpDown.Location = new System.Drawing.Point(475, 585);
            this.mushroomsNumericUpDown.Name = "mushroomsNumericUpDown";
            this.mushroomsNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.mushroomsNumericUpDown.TabIndex = 55;
            this.mushroomsNumericUpDown.ValueChanged += new System.EventHandler(this.mushroomsNumericUpDown_ValueChanged);
            // 
            // sausageNumericUpDown
            // 
            this.sausageNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.sausageNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sausageNumericUpDown.Location = new System.Drawing.Point(475, 401);
            this.sausageNumericUpDown.Name = "sausageNumericUpDown";
            this.sausageNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.sausageNumericUpDown.TabIndex = 55;
            this.sausageNumericUpDown.ValueChanged += new System.EventHandler(this.sausageNumericUpDown_ValueChanged);
            // 
            // salamiNumericUpDown
            // 
            this.salamiNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.salamiNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.salamiNumericUpDown.Location = new System.Drawing.Point(475, 539);
            this.salamiNumericUpDown.Name = "salamiNumericUpDown";
            this.salamiNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.salamiNumericUpDown.TabIndex = 55;
            this.salamiNumericUpDown.ValueChanged += new System.EventHandler(this.salamiNumericUpDown_ValueChanged);
            // 
            // hamNumericUpDown
            // 
            this.hamNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.hamNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.hamNumericUpDown.Location = new System.Drawing.Point(475, 357);
            this.hamNumericUpDown.Name = "hamNumericUpDown";
            this.hamNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.hamNumericUpDown.TabIndex = 55;
            this.hamNumericUpDown.ValueChanged += new System.EventHandler(this.hamNumericUpDown_ValueChanged);
            // 
            // anchoviesNumericUpDown
            // 
            this.anchoviesNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.anchoviesNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.anchoviesNumericUpDown.Location = new System.Drawing.Point(475, 495);
            this.anchoviesNumericUpDown.Name = "anchoviesNumericUpDown";
            this.anchoviesNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.anchoviesNumericUpDown.TabIndex = 55;
            this.anchoviesNumericUpDown.ValueChanged += new System.EventHandler(this.anchoviesNumericUpDown_ValueChanged);
            // 
            // onionsNumericUpDown
            // 
            this.onionsNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.onionsNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.onionsNumericUpDown.Location = new System.Drawing.Point(475, 723);
            this.onionsNumericUpDown.Name = "onionsNumericUpDown";
            this.onionsNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.onionsNumericUpDown.TabIndex = 55;
            this.onionsNumericUpDown.ValueChanged += new System.EventHandler(this.onionsNumericUpDown_ValueChanged);
            // 
            // numericUpDown14
            // 
            this.numericUpDown14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.numericUpDown14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown14.Location = new System.Drawing.Point(475, 861);
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.Size = new System.Drawing.Size(57, 22);
            this.numericUpDown14.TabIndex = 55;
            // 
            // bellPepperNumericUpDown
            // 
            this.bellPepperNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.bellPepperNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bellPepperNumericUpDown.Location = new System.Drawing.Point(475, 677);
            this.bellPepperNumericUpDown.Name = "bellPepperNumericUpDown";
            this.bellPepperNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.bellPepperNumericUpDown.TabIndex = 55;
            this.bellPepperNumericUpDown.ValueChanged += new System.EventHandler(this.bellPepperNumericUpDown_ValueChanged);
            // 
            // jalapenoNumericUpDown
            // 
            this.jalapenoNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.jalapenoNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.jalapenoNumericUpDown.Location = new System.Drawing.Point(475, 815);
            this.jalapenoNumericUpDown.Name = "jalapenoNumericUpDown";
            this.jalapenoNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.jalapenoNumericUpDown.TabIndex = 55;
            this.jalapenoNumericUpDown.ValueChanged += new System.EventHandler(this.jalapenoNumericUpDown_ValueChanged);
            // 
            // olivesNumericUpDown
            // 
            this.olivesNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.olivesNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.olivesNumericUpDown.Location = new System.Drawing.Point(475, 633);
            this.olivesNumericUpDown.Name = "olivesNumericUpDown";
            this.olivesNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.olivesNumericUpDown.TabIndex = 55;
            this.olivesNumericUpDown.ValueChanged += new System.EventHandler(this.olivesNumericUpDown_ValueChanged);
            // 
            // blackOlivesNumericUpDown
            // 
            this.blackOlivesNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.blackOlivesNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.blackOlivesNumericUpDown.Location = new System.Drawing.Point(475, 771);
            this.blackOlivesNumericUpDown.Name = "blackOlivesNumericUpDown";
            this.blackOlivesNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.blackOlivesNumericUpDown.TabIndex = 55;
            this.blackOlivesNumericUpDown.ValueChanged += new System.EventHandler(this.blackOlivesNumericUpDown_ValueChanged);
            // 
            // spinachNumericUpDown
            // 
            this.spinachNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.spinachNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.spinachNumericUpDown.Location = new System.Drawing.Point(475, 953);
            this.spinachNumericUpDown.Name = "spinachNumericUpDown";
            this.spinachNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.spinachNumericUpDown.TabIndex = 55;
            this.spinachNumericUpDown.ValueChanged += new System.EventHandler(this.spinachNumericUpDown_ValueChanged);
            // 
            // oreganoNumericUpDown
            // 
            this.oreganoNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.oreganoNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.oreganoNumericUpDown.Location = new System.Drawing.Point(475, 1091);
            this.oreganoNumericUpDown.Name = "oreganoNumericUpDown";
            this.oreganoNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.oreganoNumericUpDown.TabIndex = 55;
            this.oreganoNumericUpDown.ValueChanged += new System.EventHandler(this.oreganoNumericUpDown_ValueChanged);
            // 
            // basilNumericUpDown
            // 
            this.basilNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.basilNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.basilNumericUpDown.Location = new System.Drawing.Point(475, 907);
            this.basilNumericUpDown.Name = "basilNumericUpDown";
            this.basilNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.basilNumericUpDown.TabIndex = 55;
            this.basilNumericUpDown.ValueChanged += new System.EventHandler(this.basilNumericUpDown_ValueChanged);
            // 
            // garlicNumericUpDown
            // 
            this.garlicNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.garlicNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.garlicNumericUpDown.Location = new System.Drawing.Point(475, 1045);
            this.garlicNumericUpDown.Name = "garlicNumericUpDown";
            this.garlicNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.garlicNumericUpDown.TabIndex = 55;
            this.garlicNumericUpDown.ValueChanged += new System.EventHandler(this.garlicNumericUpDown_ValueChanged);
            // 
            // chiliPepperNumericUpDown
            // 
            this.chiliPepperNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.chiliPepperNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chiliPepperNumericUpDown.Location = new System.Drawing.Point(475, 863);
            this.chiliPepperNumericUpDown.Name = "chiliPepperNumericUpDown";
            this.chiliPepperNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.chiliPepperNumericUpDown.TabIndex = 55;
            this.chiliPepperNumericUpDown.ValueChanged += new System.EventHandler(this.chiliPepperNumericUpDown_ValueChanged);
            // 
            // tomatoNumericUpDown
            // 
            this.tomatoNumericUpDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.tomatoNumericUpDown.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tomatoNumericUpDown.Location = new System.Drawing.Point(475, 1001);
            this.tomatoNumericUpDown.Name = "tomatoNumericUpDown";
            this.tomatoNumericUpDown.Size = new System.Drawing.Size(57, 22);
            this.tomatoNumericUpDown.TabIndex = 55;
            this.tomatoNumericUpDown.ValueChanged += new System.EventHandler(this.tomatoNumericUpDown_ValueChanged);
            // 
            // mozzarellaLbl
            // 
            this.mozzarellaLbl.AutoSize = true;
            this.mozzarellaLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.mozzarellaLbl.Location = new System.Drawing.Point(215, 79);
            this.mozzarellaLbl.Name = "mozzarellaLbl";
            this.mozzarellaLbl.Size = new System.Drawing.Size(131, 32);
            this.mozzarellaLbl.TabIndex = 58;
            this.mozzarellaLbl.Text = "Mozzarella";
            // 
            // regularCheeseLbl
            // 
            this.regularCheeseLbl.AutoSize = true;
            this.regularCheeseLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.regularCheeseLbl.Location = new System.Drawing.Point(215, 125);
            this.regularCheeseLbl.Name = "regularCheeseLbl";
            this.regularCheeseLbl.Size = new System.Drawing.Size(172, 32);
            this.regularCheeseLbl.TabIndex = 58;
            this.regularCheeseLbl.Text = "Regular cheese";
            this.regularCheeseLbl.Click += new System.EventHandler(this.regularCheeseLbl_Click);
            // 
            // parmesanLbl
            // 
            this.parmesanLbl.AutoSize = true;
            this.parmesanLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.parmesanLbl.Location = new System.Drawing.Point(215, 217);
            this.parmesanLbl.Name = "parmesanLbl";
            this.parmesanLbl.Size = new System.Drawing.Size(117, 32);
            this.parmesanLbl.TabIndex = 58;
            this.parmesanLbl.Text = "Parmesan";
            // 
            // cheddarLbl
            // 
            this.cheddarLbl.AutoSize = true;
            this.cheddarLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.cheddarLbl.Location = new System.Drawing.Point(215, 263);
            this.cheddarLbl.Name = "cheddarLbl";
            this.cheddarLbl.Size = new System.Drawing.Size(106, 32);
            this.cheddarLbl.TabIndex = 58;
            this.cheddarLbl.Text = "Cheddar";
            // 
            // fetaLbl
            // 
            this.fetaLbl.AutoSize = true;
            this.fetaLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.fetaLbl.Location = new System.Drawing.Point(215, 309);
            this.fetaLbl.Name = "fetaLbl";
            this.fetaLbl.Size = new System.Drawing.Size(59, 32);
            this.fetaLbl.TabIndex = 58;
            this.fetaLbl.Text = "Feta";
            // 
            // hamLbl
            // 
            this.hamLbl.AutoSize = true;
            this.hamLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.hamLbl.Location = new System.Drawing.Point(215, 355);
            this.hamLbl.Name = "hamLbl";
            this.hamLbl.Size = new System.Drawing.Size(66, 32);
            this.hamLbl.TabIndex = 58;
            this.hamLbl.Text = "Ham";
            // 
            // sausageLbl
            // 
            this.sausageLbl.AutoSize = true;
            this.sausageLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.sausageLbl.Location = new System.Drawing.Point(215, 401);
            this.sausageLbl.Name = "sausageLbl";
            this.sausageLbl.Size = new System.Drawing.Size(109, 32);
            this.sausageLbl.TabIndex = 58;
            this.sausageLbl.Text = "Sausages";
            // 
            // baconLbl
            // 
            this.baconLbl.AutoSize = true;
            this.baconLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.baconLbl.Location = new System.Drawing.Point(215, 447);
            this.baconLbl.Name = "baconLbl";
            this.baconLbl.Size = new System.Drawing.Size(78, 32);
            this.baconLbl.TabIndex = 58;
            this.baconLbl.Text = "Bacon";
            // 
            // anchoviesLbl
            // 
            this.anchoviesLbl.AutoSize = true;
            this.anchoviesLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.anchoviesLbl.Location = new System.Drawing.Point(215, 493);
            this.anchoviesLbl.Name = "anchoviesLbl";
            this.anchoviesLbl.Size = new System.Drawing.Size(125, 32);
            this.anchoviesLbl.TabIndex = 58;
            this.anchoviesLbl.Text = "Anchovies";
            // 
            // salamiLbl
            // 
            this.salamiLbl.AutoSize = true;
            this.salamiLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.salamiLbl.Location = new System.Drawing.Point(215, 539);
            this.salamiLbl.Name = "salamiLbl";
            this.salamiLbl.Size = new System.Drawing.Size(83, 32);
            this.salamiLbl.TabIndex = 58;
            this.salamiLbl.Text = "Salami";
            // 
            // mushroomsLbl
            // 
            this.mushroomsLbl.AutoSize = true;
            this.mushroomsLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.mushroomsLbl.Location = new System.Drawing.Point(215, 585);
            this.mushroomsLbl.Name = "mushroomsLbl";
            this.mushroomsLbl.Size = new System.Drawing.Size(140, 32);
            this.mushroomsLbl.TabIndex = 58;
            this.mushroomsLbl.Text = "Mushrooms";
            // 
            // olivesLbl
            // 
            this.olivesLbl.AutoSize = true;
            this.olivesLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.olivesLbl.Location = new System.Drawing.Point(215, 631);
            this.olivesLbl.Name = "olivesLbl";
            this.olivesLbl.Size = new System.Drawing.Size(79, 32);
            this.olivesLbl.TabIndex = 58;
            this.olivesLbl.Text = "Olives";
            // 
            // bellPepperLbl
            // 
            this.bellPepperLbl.AutoSize = true;
            this.bellPepperLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.bellPepperLbl.Location = new System.Drawing.Point(215, 677);
            this.bellPepperLbl.Name = "bellPepperLbl";
            this.bellPepperLbl.Size = new System.Drawing.Size(133, 32);
            this.bellPepperLbl.TabIndex = 58;
            this.bellPepperLbl.Text = "Bell pepper";
            // 
            // onionsLbl
            // 
            this.onionsLbl.AutoSize = true;
            this.onionsLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.onionsLbl.Location = new System.Drawing.Point(215, 723);
            this.onionsLbl.Name = "onionsLbl";
            this.onionsLbl.Size = new System.Drawing.Size(90, 32);
            this.onionsLbl.TabIndex = 58;
            this.onionsLbl.Text = "Onions";
            // 
            // blackOlivesLbl
            // 
            this.blackOlivesLbl.AutoSize = true;
            this.blackOlivesLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.blackOlivesLbl.Location = new System.Drawing.Point(215, 769);
            this.blackOlivesLbl.Name = "blackOlivesLbl";
            this.blackOlivesLbl.Size = new System.Drawing.Size(134, 32);
            this.blackOlivesLbl.TabIndex = 58;
            this.blackOlivesLbl.Text = "Black olives";
            // 
            // jalapenoLbl
            // 
            this.jalapenoLbl.AutoSize = true;
            this.jalapenoLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.jalapenoLbl.Location = new System.Drawing.Point(215, 815);
            this.jalapenoLbl.Name = "jalapenoLbl";
            this.jalapenoLbl.Size = new System.Drawing.Size(105, 32);
            this.jalapenoLbl.TabIndex = 58;
            this.jalapenoLbl.Text = "Jalapeno";
            // 
            // chiliPepperLbl
            // 
            this.chiliPepperLbl.AutoSize = true;
            this.chiliPepperLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.chiliPepperLbl.Location = new System.Drawing.Point(215, 861);
            this.chiliPepperLbl.Name = "chiliPepperLbl";
            this.chiliPepperLbl.Size = new System.Drawing.Size(144, 32);
            this.chiliPepperLbl.TabIndex = 58;
            this.chiliPepperLbl.Text = "Chili pepper";
            // 
            // basilLbl
            // 
            this.basilLbl.AutoSize = true;
            this.basilLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.basilLbl.Location = new System.Drawing.Point(215, 907);
            this.basilLbl.Name = "basilLbl";
            this.basilLbl.Size = new System.Drawing.Size(62, 32);
            this.basilLbl.TabIndex = 58;
            this.basilLbl.Text = "Basil";
            // 
            // spinachLbl
            // 
            this.spinachLbl.AutoSize = true;
            this.spinachLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.spinachLbl.Location = new System.Drawing.Point(215, 953);
            this.spinachLbl.Name = "spinachLbl";
            this.spinachLbl.Size = new System.Drawing.Size(98, 32);
            this.spinachLbl.TabIndex = 58;
            this.spinachLbl.Text = "Spinach";
            // 
            // tomatoLbl
            // 
            this.tomatoLbl.AutoSize = true;
            this.tomatoLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.tomatoLbl.Location = new System.Drawing.Point(215, 999);
            this.tomatoLbl.Name = "tomatoLbl";
            this.tomatoLbl.Size = new System.Drawing.Size(94, 32);
            this.tomatoLbl.TabIndex = 58;
            this.tomatoLbl.Text = "Tomato";
            // 
            // garlicLbl
            // 
            this.garlicLbl.AutoSize = true;
            this.garlicLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.garlicLbl.Location = new System.Drawing.Point(215, 1045);
            this.garlicLbl.Name = "garlicLbl";
            this.garlicLbl.Size = new System.Drawing.Size(77, 32);
            this.garlicLbl.TabIndex = 58;
            this.garlicLbl.Text = "Garlic";
            // 
            // oreganoLbl
            // 
            this.oreganoLbl.AutoSize = true;
            this.oreganoLbl.Font = new System.Drawing.Font("Palatino Linotype", 12F);
            this.oreganoLbl.Location = new System.Drawing.Point(215, 1091);
            this.oreganoLbl.Name = "oreganoLbl";
            this.oreganoLbl.Size = new System.Drawing.Size(105, 32);
            this.oreganoLbl.TabIndex = 58;
            this.oreganoLbl.Text = "Oregano";
            // 
            // PickToppings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(73)))), ((int)(((byte)(61)))));
            this.ClientSize = new System.Drawing.Size(930, 450);
            this.Controls.Add(this.regularCheeseLbl);
            this.Controls.Add(this.oreganoLbl);
            this.Controls.Add(this.garlicLbl);
            this.Controls.Add(this.tomatoLbl);
            this.Controls.Add(this.chiliPepperLbl);
            this.Controls.Add(this.jalapenoLbl);
            this.Controls.Add(this.bellPepperLbl);
            this.Controls.Add(this.spinachLbl);
            this.Controls.Add(this.olivesLbl);
            this.Controls.Add(this.blackOlivesLbl);
            this.Controls.Add(this.anchoviesLbl);
            this.Controls.Add(this.basilLbl);
            this.Controls.Add(this.mushroomsLbl);
            this.Controls.Add(this.onionsLbl);
            this.Controls.Add(this.baconLbl);
            this.Controls.Add(this.salamiLbl);
            this.Controls.Add(this.sausageLbl);
            this.Controls.Add(this.hamLbl);
            this.Controls.Add(this.fetaLbl);
            this.Controls.Add(this.cheddarLbl);
            this.Controls.Add(this.parmesanLbl);
            this.Controls.Add(this.mozzarellaLbl);
            this.Controls.Add(this.tomatoNumericUpDown);
            this.Controls.Add(this.blackOlivesNumericUpDown);
            this.Controls.Add(this.anchoviesNumericUpDown);
            this.Controls.Add(this.parmesanNumericUpDown);
            this.Controls.Add(this.chiliPepperNumericUpDown);
            this.Controls.Add(this.olivesNumericUpDown);
            this.Controls.Add(this.hamNumericUpDown);
            this.Controls.Add(this.mozzarellaNumericUpDown);
            this.Controls.Add(this.garlicNumericUpDown);
            this.Controls.Add(this.jalapenoNumericUpDown);
            this.Controls.Add(this.salamiNumericUpDown);
            this.Controls.Add(this.cheddarNumericUpDown);
            this.Controls.Add(this.basilNumericUpDown);
            this.Controls.Add(this.bellPepperNumericUpDown);
            this.Controls.Add(this.sausageNumericUpDown);
            this.Controls.Add(this.regularCheeseNumericUpDown);
            this.Controls.Add(this.oreganoNumericUpDown);
            this.Controls.Add(this.spinachNumericUpDown);
            this.Controls.Add(this.numericUpDown14);
            this.Controls.Add(this.onionsNumericUpDown);
            this.Controls.Add(this.mushroomsNumericUpDown);
            this.Controls.Add(this.baconNumericUpDown);
            this.Controls.Add(this.fetaNumericUpDown);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.lactoseFreeCheeseCheckBox);
            this.Controls.Add(this.addTopingsLbl);
            this.Name = "PickToppings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PickToppings";
            this.Load += new System.EventHandler(this.PickToppings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.regularCheeseNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mozzarellaNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fetaNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cheddarNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.parmesanNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baconNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mushroomsNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sausageNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salamiNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hamNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.anchoviesNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onionsNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bellPepperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jalapenoNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.olivesNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackOlivesNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinachNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oreganoNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basilNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.garlicNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chiliPepperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tomatoNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.CheckBox lactoseFreeCheeseCheckBox;
        private System.Windows.Forms.Label addTopingsLbl;
        private System.Windows.Forms.NumericUpDown regularCheeseNumericUpDown;
        private System.Windows.Forms.NumericUpDown mozzarellaNumericUpDown;
        private System.Windows.Forms.NumericUpDown fetaNumericUpDown;
        private System.Windows.Forms.NumericUpDown cheddarNumericUpDown;
        private System.Windows.Forms.NumericUpDown parmesanNumericUpDown;
        private System.Windows.Forms.NumericUpDown baconNumericUpDown;
        private System.Windows.Forms.NumericUpDown mushroomsNumericUpDown;
        private System.Windows.Forms.NumericUpDown sausageNumericUpDown;
        private System.Windows.Forms.NumericUpDown salamiNumericUpDown;
        private System.Windows.Forms.NumericUpDown hamNumericUpDown;
        private System.Windows.Forms.NumericUpDown anchoviesNumericUpDown;
        private System.Windows.Forms.NumericUpDown onionsNumericUpDown;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.NumericUpDown bellPepperNumericUpDown;
        private System.Windows.Forms.NumericUpDown jalapenoNumericUpDown;
        private System.Windows.Forms.NumericUpDown olivesNumericUpDown;
        private System.Windows.Forms.NumericUpDown blackOlivesNumericUpDown;
        private System.Windows.Forms.NumericUpDown spinachNumericUpDown;
        private System.Windows.Forms.NumericUpDown oreganoNumericUpDown;
        private System.Windows.Forms.NumericUpDown basilNumericUpDown;
        private System.Windows.Forms.NumericUpDown garlicNumericUpDown;
        private System.Windows.Forms.NumericUpDown chiliPepperNumericUpDown;
        private System.Windows.Forms.NumericUpDown tomatoNumericUpDown;
        private System.Windows.Forms.Label mozzarellaLbl;
        private System.Windows.Forms.Label regularCheeseLbl;
        private System.Windows.Forms.Label parmesanLbl;
        private System.Windows.Forms.Label cheddarLbl;
        private System.Windows.Forms.Label fetaLbl;
        private System.Windows.Forms.Label hamLbl;
        private System.Windows.Forms.Label sausageLbl;
        private System.Windows.Forms.Label baconLbl;
        private System.Windows.Forms.Label anchoviesLbl;
        private System.Windows.Forms.Label salamiLbl;
        private System.Windows.Forms.Label mushroomsLbl;
        private System.Windows.Forms.Label olivesLbl;
        private System.Windows.Forms.Label bellPepperLbl;
        private System.Windows.Forms.Label onionsLbl;
        private System.Windows.Forms.Label blackOlivesLbl;
        private System.Windows.Forms.Label jalapenoLbl;
        private System.Windows.Forms.Label chiliPepperLbl;
        private System.Windows.Forms.Label basilLbl;
        private System.Windows.Forms.Label spinachLbl;
        private System.Windows.Forms.Label tomatoLbl;
        private System.Windows.Forms.Label garlicLbl;
        private System.Windows.Forms.Label oreganoLbl;
    }
}